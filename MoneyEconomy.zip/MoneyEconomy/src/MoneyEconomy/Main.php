<?php

namespace MoneyEconomy;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class Main extends PluginBase {

    private $economyManager;
    private $formManager;

    public function onEnable(): void {
        try {
            $this->saveDefaultConfig();
            $this->economyManager = new EconomyManager($this);
            $this->formManager = new FormManager($this->economyManager);
            $this->getServer()->getPluginManager()->registerEvents(new EventListener($this->economyManager), $this);
            $this->getLogger()->info("MoneyEconomy успешно включен!");
        } catch (\Exception $e) {
            $this->getLogger()->error("Ошибка при включении MoneyEconomy: " . $e->getMessage());
            $this->getLogger()->error("Stack trace: " . $e->getTraceAsString());
        }
    }

    public function onDisable(): void {
        try {
            $this->getLogger()->info("MoneyEconomy успешно выключен!");
        } catch (\Exception $e) {
            $this->getLogger()->error("Ошибка при выключении MoneyEconomy: " . $e->getMessage());
        }
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        try {
            switch ($command->getName()) {
                case "money":
                    if ($sender instanceof Player) {
                        $this->formManager->sendMainMenu($sender);
                    } else {
                        $sender->sendMessage("Данную команду запрещено использовать в консоли сервера. Прейдите в игру!");
                    }
                    return true;
                    
                case "moneyadmin":
                    if ($sender->hasPermission("moneyeconomy.admin")) {
                        $this->handleAdminCommand($sender, $args);
                    } else {
                        $sender->sendMessage("У вас нет прав для использования этой команды!");
                    }
                    return true;
            }
        } catch (\Exception $e) {
            $this->getLogger()->error("Ошибка при выполнении команды: " . $e->getMessage());
            $sender->sendMessage("Произошла ошибка при выполнении команды. Обратитесь к администратору.");
        }
        return false;
    }

    private function handleAdminCommand(CommandSender $sender, array $args): void {
        if (empty($args)) {
            $sender->sendMessage("=== Команды MoneyEconomy Admin ===");
            $sender->sendMessage("/moneyadmin wipe start - Начать вайп");
            $sender->sendMessage("/moneyadmin wipe end - Завершить вайп");
            $sender->sendMessage("/moneyadmin wipe status - Статус вайпа");
            $sender->sendMessage("/moneyadmin give <игрок> <сумма> - Выдать деньги");
            $sender->sendMessage("/moneyadmin take <игрок> <сумма> - Забрать деньги");
            $sender->sendMessage("/moneyadmin set <игрок> <сумма> - Установить баланс");
            $sender->sendMessage("/moneyadmin transactions [игрок] - История транзакций");
            $sender->sendMessage("/moneyadmin ranks - Список рангов");
            $sender->sendMessage("/moneyadmin rank <игрок> - Ранг игрока");
            $sender->sendMessage("/moneyadmin reset <игрок> - Сброс статистики игрока");
            $sender->sendMessage("/moneyadmin checkinactive - Проверить неактивных игроков");
            return;
        }

        switch ($args[0]) {
            case "wipe":
                if (!isset($args[1])) {
                    $sender->sendMessage("Использование: /moneyadmin wipe <start|end|status>");
                    return;
                }
                
                switch ($args[1]) {
                    case "start":
                        $this->economyManager->startWipe();
                        $sender->sendMessage("Вайп начался!");
                        $this->getServer()->broadcastMessage("[MoneyEconomy] Начался вайп экономики! Все балансы сброшены.");
                        break;
                        
                    case "end":
                        $this->economyManager->endWipe();
                        $sender->sendMessage("Вайп завершен!");
                        $this->getServer()->broadcastMessage("[MoneyEconomy] Вайп экономики завершен!");
                        break;
                        
                    case "status":
                        if ($this->economyManager->isInWipe()) {
                            $wipeInfo = $this->economyManager->getCurrentWipeInfo();
                            $duration = time() - $wipeInfo["start_time"];
                            $sender->sendMessage("=== Статус вайпа ===");
                            $sender->sendMessage("Активен: Да");
                            $sender->sendMessage("Начало: " . date("d.m.Y H:i", $wipeInfo["start_time"]));
                            $sender->sendMessage("Длительность: " . gmdate("H:i:s", $duration));
                            $sender->sendMessage("Игроков: " . $wipeInfo["players_count"]);
                        } else {
                            $sender->sendMessage("Вайп не активен");
                        }
                        break;
                }
                break;
                
            case "give":
                if (count($args) < 3) {
                    $sender->sendMessage("Использование: /moneyadmin give <игрок> <сумма>");
                    return;
                }
                
                $playerName = $args[1];
                $amount = (float)$args[2];
                
                if ($amount <= 0) {
                    $sender->sendMessage("Сумма должна быть больше 0!");
                    return;
                }
                
                $this->economyManager->addBalance($playerName, $amount, "Выдача администратором");
                $sender->sendMessage("Вы успешно выдали " . number_format($amount, 0, '.', '') . " монет игроку " . $playerName);
                
                $player = $this->getServer()->getPlayerExact($playerName);
                if ($player !== null) {
                    $player->sendMessage("Администратор выдал вам " . number_format($amount, 0, '.', '') . " монет!");
                }
                break;
                
            case "take":
                if (count($args) < 3) {
                    $sender->sendMessage("Использование: /moneyadmin take <игрок> <сумма>");
                    return;
                }
                
                $playerName = $args[1];
                $amount = (float)$args[2];
                
                if ($amount <= 0) {
                    $sender->sendMessage("Сумма должна быть больше 0!");
                    return;
                }
                
                if ($this->economyManager->reduceBalance($playerName, $amount, "Забор администратором")) {
                    $sender->sendMessage("Вы успешно забрали " . number_format($amount, 0, '.', '') . " монет у игрока " . $playerName);
                    
                    $player = $this->getServer()->getPlayerExact($playerName);
                    if ($player !== null) {
                        $player->sendMessage("Администратор забрал у вас " . number_format($amount, 0, '.', '') . " монет!");
                    }
                } else {
                    $sender->sendMessage("У игрока недостаточно средств!");
                }
                break;
                
            case "set":
                if (count($args) < 3) {
                    $sender->sendMessage("Использование: /moneyadmin set <игрок> <сумма>");
                    return;
                }
                
                $playerName = $args[1];
                $amount = (float)$args[2];
                
                if ($amount < 0) {
                    $sender->sendMessage("Сумма не может быть отрицательной!");
                    return;
                }
                
                $playerData = $this->economyManager->getPlayerData($playerName);
                $playerData["balance"] = $amount;
                $this->economyManager->setPlayerData($playerName, $playerData);
                
                $sender->sendMessage("Вы успешно установили баланс " . number_format($amount, 0, '.', '') . " монет для игрока " . $playerName);
                break;
                
            case "transactions":
                if (isset($args[1])) {
                    $playerName = $args[1];
                    $transactions = $this->economyManager->getPlayerTransactions($playerName, 10);
                    
                    $sender->sendMessage("=== Транзакции игрока " . $playerName . " ===");
                    if (empty($transactions)) {
                        $sender->sendMessage("Нет транзакций");
                    } else {
                        foreach ($transactions as $transaction) {
                            $type = "";
                            switch($transaction["type"]) {
                                case "receive":
                                    $type = "Получение";
                                    break;
                                case "send":
                                    $type = "Списание";
                                    break;
                                case "transfer":
                                    $type = "Перевод";
                                    break;
                                case "receive_transfer":
                                    $type = "Получение перевода";
                                    break;
                                default:
                                    $type = $transaction["type"];
                                    break;
                            }
                            $sender->sendMessage("[" . $transaction["date"] . "] " . $type . " " . number_format($transaction["amount"], 0, '.', '') . " (" . $transaction["description"] . ")");
                        }
                    }
                } else {
                    $transactions = $this->economyManager->getAllTransactions(10);
                    
                    $sender->sendMessage("=== Последние транзакции ===");
                    if (empty($transactions)) {
                        $sender->sendMessage("Нет транзакций");
                    } else {
                        foreach ($transactions as $transaction) {
                            $type = "";
                            switch($transaction["type"]) {
                                case "receive":
                                    $type = "Получение";
                                    break;
                                case "send":
                                    $type = "Списание";
                                    break;
                                case "transfer":
                                    $type = "Перевод";
                                    break;
                                case "receive_transfer":
                                    $type = "Получение перевода";
                                    break;
                                default:
                                    $type = $transaction["type"];
                                    break;
                            }
                            $sender->sendMessage("[" . $transaction["date"] . "] " . $transaction["player"] . " " . $type . " " . number_format($transaction["amount"], 0, '.', '') . " (" . $transaction["description"] . ")");
                        }
                    }
                }
                break;
                
            case "ranks":
                $ranks = $this->economyManager->getAllRanks();
                $sender->sendMessage("=== Ранги ===");
                foreach ($ranks as $rank) {
                    $players = $this->economyManager->getRankPlayers($rank);
                    $count = count($players);
                    $sender->sendMessage($rank . " (" . $count . " игроков)");
                }
                break;
                
            case "rank":
                if (count($args) < 2) {
                    $sender->sendMessage("Использование: /moneyadmin rank <игрок>");
                    return;
                }
                
                $playerName = $args[1];
                $rank = $this->economyManager->getPlayerRank($playerName);
                $sender->sendMessage("Ранг игрока " . $playerName . ": " . $rank);
                break;
                
            case "reset":
                if (count($args) < 2) {
                    $sender->sendMessage("Использование: /moneyadmin reset <игрок>");
                    return;
                }
                
                $playerName = $args[1];
                $this->economyManager->resetPlayerStats($playerName);
                $sender->sendMessage("Статистика игрока " . $playerName . " сброшена!");
                break;
                
            case "checkinactive":
                $count = $this->economyManager->manualCheckInactivePlayers();
                $sender->sendMessage("Проверка неактивных игроков завершена. Очищено: " . $count . " игроков");
                break;
        }
    }

    public function getEconomyManager() {
        return $this->economyManager;
    }
}