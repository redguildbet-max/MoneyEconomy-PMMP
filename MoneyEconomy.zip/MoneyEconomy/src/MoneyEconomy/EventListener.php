<?php

namespace MoneyEconomy;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\scheduler\ClosureTask;

class EventListener implements Listener {

    private $economyManager;
    private $formManager;

    public function __construct($economyManager) {
        $this->economyManager = $economyManager;
        $this->formManager = new FormManager($economyManager);
    }

    public function onPlayerJoin(PlayerJoinEvent $event): void {
        try {
            $player = $event->getPlayer();
            $this->economyManager->getPlayerData($player->getName());
            
            if ($this->economyManager->hasOfflineTransfers($player->getName())) {
                $player->getServer()->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($player) {
                    try {
                        if ($player->isOnline()) {
                            $this->formManager->sendOfflineTransfersNotification($player);
                        }
                    } catch (\Exception $e) {
                        $this->economyManager->plugin->getLogger()->error("Ошибка при отправке уведомления офлайн переводов: " . $e->getMessage());
                    }
                }), 60);
            }
        } catch (\Exception $e) {
            $this->economyManager->plugin->getLogger()->error("Ошибка при обработке входа игрока: " . $e->getMessage());
        }
    }
}