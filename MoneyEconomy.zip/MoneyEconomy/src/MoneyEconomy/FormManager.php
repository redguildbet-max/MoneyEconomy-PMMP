<?php

namespace MoneyEconomy;

use pocketmine\player\Player;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\CustomForm;

class FormManager {

    private $economyManager;

    public function __construct($economyManager) {
        $this->economyManager = $economyManager;
    }

    public function sendMainMenu(Player $player): void {
        try {
            $form = new SimpleForm(function(Player $player, ?int $data) {
                if ($data === null) return;
                
                try {
                    switch ($data) {
                        case 0:
                            $this->sendTransferForm($player);
                            break;
                        case 1:
                            $this->sendTopPlayersForm($player);
                            break;
                        case 2:
                            $this->sendTransactionsForm($player);
                            break;
                        case 3:
                            $this->sendRanksForm($player);
                            break;
                        case 4:
                            if ($player->hasPermission("moneyeconomy.admin")) {
                                $this->sendReduceForm($player);
                            } else {
                                $player->sendMessage("У вас нет прав для этой команды!");
                            }
                            break;
                        case 5:
                            if ($player->hasPermission("moneyeconomy.admin")) {
                                $this->sendAddForm($player);
                            } else {
                                $player->sendMessage("У вас нет прав для этой команды!");
                            }
                            break;
                        case 6:
                            if ($player->hasPermission("moneyeconomy.admin")) {
                                $this->sendSetLimitForm($player);
                            } else {
                                $player->sendMessage("У вас нет прав для этой команды!");
                            }
                            break;
                        case 7:
                            if ($player->hasPermission("moneyeconomy.admin")) {
                                $this->sendRemoveLimitForm($player);
                            } else {
                                $player->sendMessage("У вас нет прав для этой команды!");
                            }
                            break;
                        case 8:
                            if ($player->hasPermission("moneyeconomy.admin")) {
                                $this->sendWipeManagementForm($player);
                            } else {
                                $player->sendMessage("У вас нет прав для этой команды!");
                            }
                            break;
                    }
                } catch (\Exception $e) {
                    $this->economyManager->plugin->getLogger()->error("Ошибка в обработчике формы: " . $e->getMessage());
                    $player->sendMessage("Произошла ошибка. Попробуйте позже.");
                }
            });

            $playerData = $this->economyManager->getPlayerData($player->getName());
            $topPlayers = $this->economyManager->getTopPlayers(3);

            $topText = "";
            $i = 1;
            foreach ($topPlayers as $name => $data) {
                $topText .= "  $i. $name - " . number_format($data['balance'], 0, '.', ' ') . " монет\n";
                $i++;
            }

            $content = "Добро пожаловать {$player->getName()}, в систему экономики сервера!\n";
            $content .= "В данном меню вы можете перевести, пополнить или отнять деньги у игрока.\n";
            $content .= "В данном меню есть возможности как для простых игроков, так и для администрации сервера.\n";
            $content .= "Желаем вам приятной игры на нашем сервере!\n\n";
            $content .= "• В данный момент ваш баланс: " . number_format($playerData['balance'], 0, '.', ' ') . " монет\n";
            $content .= "• Ваши траты в этом вайпе: " . number_format($playerData['spent'], 0, '.', ' ') . " монет\n";
            $content .= "• Ваши доходы в этом вайпе: " . number_format($playerData['earned'], 0, '.', ' ') . " монет\n";
            $content .= "• Ваш ранг: " . $this->economyManager->getPlayerRank($player->getName()) . "\n";
            $content .= "• Всего заработано: " . number_format($playerData['total_earned'], 0, '.', ' ') . " монет\n\n";
            $content .= "• Топ 3 места по балансу:\n$topText";

            if ($this->economyManager->isInWipe()) {
                $wipeInfo = $this->economyManager->getCurrentWipeInfo();
                $duration = time() - $wipeInfo["start_time"];
                $content .= "[ВАЙП АКТИВЕН] Длительность: " . gmdate("H:i:s", $duration) . "\n\n";
            }

            $form->setTitle("Меню Экономики - Добро пожаловать");
            $form->setContent($content);
            
            $form->addButton("Перевести деньги игроку");
            $form->addButton("Узнать топ 25 игроков сервера по балансу");
            $form->addButton("История моих переводов");
            $form->addButton("Система рангов");
            
            if ($player->hasPermission("moneyeconomy.admin")) {
                $form->addButton("Отнять деньги у игрока");
                $form->addButton("Добавить деньги игроку");
                $form->addButton("Установить лимит баланса игрока");
                $form->addButton("Отнять лимит баланса игрока");
                $form->addButton("Управление вайпом");
            }
            
            $player->sendForm($form);
        } catch (\Exception $e) {
            $this->economyManager->plugin->getLogger()->error("Ошибка при создании главного меню: " . $e->getMessage());
            $player->sendMessage("Произошла ошибка при открытии меню. Попробуйте позже.");
        }
    }

    private function sendTransferForm(Player $player): void {
        $form = new SimpleForm(function(Player $player, ?int $data) {
            if ($data === null || $data === 0) return;
            
            $players = $this->getOnlinePlayers();
            if (isset($players[$data - 1])) {
                $targetName = $players[$data - 1];
                $this->sendTransferAmountForm($player, $targetName);
            }
        });

        $form->setTitle("Переводы Игрокам");
        $form->setContent("Выберите игрока для перевода:");
        
        $players = $this->getOnlinePlayers();
        foreach ($players as $playerName) {
            if ($playerName !== $player->getName()) {
                $form->addButton($playerName);
            }
        }
        $form->addButton("Назад");
        
        $player->sendForm($form);
    }

    private function sendTransferAmountForm(Player $player, string $targetName): void {
        $form = new SimpleForm(function(Player $player, ?int $data) use ($targetName) {
            if ($data === null || $data === 5) return;
            
            $amounts = [100000, 500000, 1000000, 5000000, 30000000];
            if (isset($amounts[$data])) {
                $amount = $amounts[$data];
                $this->processTransfer($player, $targetName, $amount);
            }
        });

        $form->setTitle("Переводы Игрокам");
        $form->setContent("Выберите сумму для перевода игроку $targetName:");
        
        $amounts = [100000, 500000, 1000000, 5000000, 30000000];
        foreach ($amounts as $amount) {
            $commission = $this->economyManager->calculateCommission($amount, $player->getName());
            $total = $amount + $commission;
            
            if ($commission > 0) {
                $form->addButton(number_format($amount, 0, '.', ' ') . " монет\n(Комиссия: " . number_format($commission, 0, '.', ' ') . " монет)");
            } else {
                $form->addButton(number_format($amount, 0, '.', ' ') . " монет\n(Без комиссии)");
            }
        }
        $form->addButton("Назад");
        
        $player->sendForm($form);
    }

    private function processTransfer(Player $player, string $targetName, float $amount): void {
        $result = $this->economyManager->transferMoney($player->getName(), $targetName, $amount);
        
        if ($result["success"]) {
            $commission = $result["commission"];
            $total = $result["total"];
            
            $checkCode = $this->generateCode(10);
            $accountCode = $this->generateCode(20);
            
            $targetPlayer = $this->getPlayerByName($targetName);
            if ($targetPlayer !== null) {
                $this->sendReceiveNotification($targetPlayer, $amount);
            } else {
                $this->economyManager->addOfflineTransfer($targetName, $player->getName(), $amount, $commission);
                $player->sendMessage("Ваш перевод находится в обработке. Игрок получит уведомление при следующем входе на сервер.");
            }
            
            $this->sendSuccessTransferForm($player, $targetName, $amount, $commission, $total, $checkCode, $accountCode);
        } else {
            $player->sendMessage($result["error"]);
        }
    }

    private function sendSuccessTransferForm(Player $player, string $targetName, float $amount, float $commission, float $total, string $checkCode, string $accountCode): void {
        $form = new SimpleForm(function(Player $player, ?int $data) {});
        
        $content = "Вы успешно перевели на сумму в " . number_format($amount, 0, '.', ' ') . " монет игроку $targetName!\n\n";
        
        if ($commission > 0) {
            $content .= "Комиссия: " . number_format($commission, 0, '.', ' ') . " монет\n";
            $content .= "Итого списано: " . number_format($total, 0, '.', ' ') . " монет\n\n";
        } else {
            $content .= "Комиссия: 0 монет (привилегия администратора)\n";
            $content .= "Итого списано: " . number_format($amount, 0, '.', ' ') . " монет\n\n";
        }
        
        $content .= "Ваш чек: $checkCode\n";
        $content .= "Ваш счёт: $accountCode\n";
        
        $form->setTitle("Успешные Переводы");
        $form->setContent($content);
        $form->addButton("Закрыть");
        
        $player->sendForm($form);
    }

    private function sendReceiveNotification(Player $player, float $amount): void {
        $form = new SimpleForm(function(Player $player, ?int $data) {});
        
        $content = "На ваш счёт были поступлены " . number_format($amount, 0, '.', ' ') . " монет!\n";
        
        $form->setTitle("Переводы от Игроков");
        $form->setContent($content);
        $form->addButton("Закрыть");
        
        $player->sendForm($form);
    }

    public function sendOfflineTransfersNotification(Player $player): void {
        if ($this->economyManager->hasOfflineTransfers($player->getName())) {
            $transfers = $this->economyManager->getOfflineTransfers($player->getName());
            $totalAmount = 0;
            
            foreach ($transfers as $transfer) {
                $totalAmount += $transfer["amount"];
            }
            
            $form = new SimpleForm(function(Player $player, ?int $data) {
                $this->economyManager->clearOfflineTransfers($player->getName());
            });
            
            $content = "Пока вас не было в сети, на ваш счёт поступили переводы!\n\n";
            $content .= "Общая сумма: " . number_format($totalAmount, 0, '.', ' ') . " монет\n\n";
            $content .= "Детали переводов:\n";
            
            foreach ($transfers as $transfer) {
                $content .= "• От {$transfer['from']}: " . number_format($transfer['amount'], 0, '.', ' ') . " монет\n";
            }
            
            $form->setTitle("Переводы от Игроков");
            $form->setContent($content);
            $form->addButton("Закрыть");
            
            $player->sendForm($form);
        }
    }

    private function sendReduceForm(Player $player): void {
        $form = new CustomForm(function(Player $player, ?array $data) {
            if ($data === null) return;
            
            $target = $this->getPlayerByName($data[1]);
            if ($target === null) {
                $player->sendMessage("Игрок не найден!");
                return;
            }
            
            $amount = (float)$data[2];
            if ($amount <= 0) {
                $player->sendMessage("Сумма должна быть больше 0!");
                return;
            }
            
            if ($this->economyManager->reduceBalance($target->getName(), $amount, "Забор администратором")) {
                $player->sendMessage("Вы успешно отняли " . number_format($amount, 0, '.', ' ') . " монет у игрока {$target->getName()}!");
                $target->sendMessage("У вас отняли " . number_format($amount, 0, '.', ' ') . " монет!");
            } else {
                $player->sendMessage("У игрока недостаточно средств!");
            }
        });
        
        $form->setTitle("Отнять деньги");
        $form->addLabel("Введите имя игрока и сумму для отнятия:");
        $form->addInput("Имя игрока:", "Введите ник...");
        $form->addInput("Сумма:", "Введите сумму...");
        
        $player->sendForm($form);
    }

    private function sendAddForm(Player $player): void {
        $form = new CustomForm(function(Player $player, ?array $data) {
            if ($data === null) return;
            
            $target = $this->getPlayerByName($data[1]);
            if ($target === null) {
                $player->sendMessage("Игрок не найден!");
                return;
            }
            
            $amount = (float)$data[2];
            if ($amount <= 0) {
                $player->sendMessage("Сумма должна быть больше 0!");
                return;
            }
            
            $this->economyManager->addBalance($target->getName(), $amount, "Выдача администратором");
            $player->sendMessage("Вы успешно добавили " . number_format($amount, 0, '.', ' ') . " монет игроку {$target->getName()}!");
            $target->sendMessage("Вам добавили " . number_format($amount, 0, '.', ' ') . " монет!");
        });
        
        $form->setTitle("Добавить деньги");
        $form->addLabel("Введите имя игрока и сумму для добавления:");
        $form->addInput("Имя игрока:", "Введите ник...");
        $form->addInput("Сумма:", "Введите сумму...");
        
        $player->sendForm($form);
    }

    private function sendSetLimitForm(Player $player): void {
        $form = new CustomForm(function(Player $player, ?array $data) {
            if ($data === null) return;
            
            $target = $this->getPlayerByName($data[1]);
            if ($target === null) {
                $player->sendMessage("Игрок не найден!");
                return;
            }
            
            $limit = (float)$data[2];
            if ($limit <= 0) {
                $player->sendMessage("Лимит должен быть больше 0!");
                return;
            }
            
            $this->economyManager->setLimit($target->getName(), $limit);
            $player->sendMessage("Вы установили лимит " . number_format($limit, 0, '.', ' ') . " монет для игрока {$target->getName()}!");
        });
        
        $form->setTitle("Установить лимит");
        $form->addLabel("Введите имя игрока и лимит баланса:");
        $form->addInput("Имя игрока:", "Введите ник...");
        $form->addInput("Лимит:", "Введите лимит...");
        
        $player->sendForm($form);
    }

    private function sendRemoveLimitForm(Player $player): void {
        $form = new CustomForm(function(Player $player, ?array $data) {
            if ($data === null) return;
            
            $target = $this->getPlayerByName($data[1]);
            if ($target === null) {
                $player->sendMessage("Игрок не найден!");
                return;
            }
            
            $this->economyManager->removeLimit($target->getName());
            $player->sendMessage("Вы убрали лимит баланса у игрока {$target->getName()}!");
        });
        
        $form->setTitle("Убрать лимит");
        $form->addLabel("Введите имя игрока для снятия лимита:");
        $form->addInput("Имя игрока:", "Введите ник...");
        
        $player->sendForm($form);
    }

    private function sendTopPlayersForm(Player $player): void {
        $form = new SimpleForm(function(Player $player, ?int $data) {});
        
        $topPlayers = $this->economyManager->getTopPlayers(25);
        $content = "Топ 25 игроков по балансу:\n\n";
        $i = 1;
        foreach ($topPlayers as $name => $data) {
            $rank = $this->economyManager->getPlayerRank($name);
            $content .= "$i. $name - " . number_format($data['balance'], 0, '.', ' ') . " монет ({$rank})\n";
            $i++;
        }
        
        $form->setTitle("Топ 25 игроков");
        $form->setContent($content);
        $form->addButton("Назад");
        
        $player->sendForm($form);
    }

    private function sendTransactionsForm(Player $player): void {
        $form = new SimpleForm(function(Player $player, ?int $data) {});
        
        $transactions = $this->economyManager->getPlayerTransactions($player->getName(), 15);
        $content = "Ваша история транзакций:\n\n";
        
        if (empty($transactions)) {
            $content .= "Нет транзакций\n";
        } else {
            foreach ($transactions as $transaction) {
                $typeSymbol = "";
                switch($transaction["type"]) {
                    case "receive":
                        $typeSymbol = "+";
                        break;
                    case "send":
                        $typeSymbol = "-";
                        break;
                    case "transfer":
                        $typeSymbol = "->";
                        break;
                    case "receive_transfer":
                        $typeSymbol = "<-";
                        break;
                    default:
                        $typeSymbol = "";
                        break;
                }
                
                $content .= "[" . $transaction["date"] . "] " . $typeSymbol . " " . number_format($transaction["amount"], 0, '.', ' ') . " монет\n";
                $content .= "  " . $transaction["description"] . "\n\n";
            }
        }
        
        $form->setTitle("История транзакций");
        $form->setContent($content);
        $form->addButton("Назад");
        
        $player->sendForm($form);
    }

    private function sendRanksForm(Player $player): void {
        $form = new SimpleForm(function(Player $player, ?int $data) {
            if ($data === null || $data === 0) return;
            
            $ranks = $this->economyManager->getAllRanks();
            if (isset($ranks[$data - 1])) {
                $this->sendRankDetailsForm($player, $ranks[$data - 1]);
            }
        });
        
        $ranks = $this->economyManager->getAllRanks();
        $content = "Система рангов сервера:\n\n";
        $content .= "Ваш текущий ранг: " . $this->economyManager->getPlayerRank($player->getName()) . "\n\n";
        $content .= "Все ранги:\n";
        
        $form->setTitle("Система рангов");
        $form->setContent($content);
        
        foreach ($ranks as $rank) {
            $playersCount = count($this->economyManager->getRankPlayers($rank));
            $form->addButton("$rank ($playersCount игроков)");
        }
        $form->addButton("Назад");
        
        $player->sendForm($form);
    }

    private function sendRankDetailsForm(Player $player, string $rank): void {
        $form = new SimpleForm(function(Player $player, ?int $data) {});
        
        $players = $this->economyManager->getRankPlayers($rank);
        $content = "Ранг: $rank\n\n";
        
        if (empty($players)) {
            $content .= "Нет игроков с этим рангом\n";
        } else {
            $content .= "Игроки с этим рангом:\n";
            $i = 1;
            foreach (array_slice($players, 0, 10) as $playerData) {
                $content .= "$i. {$playerData['name']} - " . number_format($playerData['balance'], 0, '.', ' ') . " монет\n";
                $i++;
            }
        }
        
        $form->setTitle("Детали ранга");
        $form->setContent($content);
        $form->addButton("Назад");
        
        $player->sendForm($form);
    }

    private function sendWipeManagementForm(Player $player): void {
        $form = new SimpleForm(function(Player $player, ?int $data) {
            if ($data === null) return;
            
            switch ($data) {
                case 0:
                    $this->economyManager->startWipe();
                    $player->sendMessage("Вайп начался!");
                    $this->economyManager->plugin->getServer()->broadcastMessage("[MoneyEconomy] Начался вайп экономики! Все балансы сброшены.");
                    break;
                case 1:
                    $this->economyManager->endWipe();
                    $player->sendMessage("Вайп завершен!");
                    $this->economyManager->plugin->getServer()->broadcastMessage("[MoneyEconomy] Вайп экономики завершен!");
                    break;
            }
        });
        
        $content = "Управление вайпом:\n\n";
        
        if ($this->economyManager->isInWipe()) {
            $wipeInfo = $this->economyManager->getCurrentWipeInfo();
            $duration = time() - $wipeInfo["start_time"];
            $content .= "Статус: АКТИВЕН\n";
            $content .= "Начало: " . date("d.m.Y H:i", $wipeInfo["start_time"]) . "\n";
            $content .= "Длительность: " . gmdate("H:i:s", $duration) . "\n";
            $content .= "Игроков: " . $wipeInfo["players_count"] . "\n\n";
            $form->addButton("Завершить вайп");
        } else {
            $content .= "Статус: НЕ АКТИВЕН\n\n";
            $form->addButton("Начать вайп");
        }
        
        $lastWipe = $this->economyManager->getLastWipeInfo();
        if (!empty($lastWipe)) {
            $content .= "Последний вайп:\n";
            $content .= "Завершен: " . date("d.m.Y H:i", $lastWipe["end_time"]) . "\n";
            $content .= "Игроков: " . $lastWipe["players_count"] . "\n";
        }
        
        $form->setTitle("Управление вайпом");
        $form->setContent($content);
        $form->addButton("Назад");
        
        $player->sendForm($form);
    }

    private function getOnlinePlayers(): array {
        $players = [];
        foreach ($this->economyManager->plugin->getServer()->getOnlinePlayers() as $player) {
            $players[] = $player->getName();
        }
        return $players;
    }

    private function getPlayerByName(string $name): ?Player {
        $player = $this->economyManager->plugin->getServer()->getPlayerByPrefix($name);
        return $player instanceof Player ? $player : null;
    }

    private function generateCode(int $length): string {
        $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $code = '';
        for ($i = 0; $i < $length; $i++) {
            $code .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $code;
    }
}