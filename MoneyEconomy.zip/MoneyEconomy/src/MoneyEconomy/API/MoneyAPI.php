<?php

namespace MoneyEconomy\API;

use MoneyEconomy\Main;
use pocketmine\player\Player;

class MoneyAPI {
    
    private static $instance = null;
    private $plugin;
    
    private function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }
    
    public static function getInstance(Main $plugin = null): self {
        if (self::$instance === null && $plugin !== null) {
            self::$instance = new self($plugin);
        }
        return self::$instance;
    }
    
    /**
     * Получить баланс игрока
     * @param string|Player $player
     * @return float
     */
    public function getBalance($player): float {
        $playerName = $player instanceof Player ? $player->getName() : $player;
        $data = $this->plugin->getEconomyManager()->getPlayerData($playerName);
        return $data["balance"] ?? 0.0;
    }
    
    /**
     * Установить баланс игрока
     * @param string|Player $player
     * @param float $amount
     * @return void
     */
    public function setBalance($player, float $amount): void {
        $playerName = $player instanceof Player ? $player->getName() : $player;
        $data = $this->plugin->getEconomyManager()->getPlayerData($playerName);
        $data["balance"] = $amount;
        $this->plugin->getEconomyManager()->setPlayerData($playerName, $data);
    }
    
    /**
     * Добавить деньги игроку
     * @param string|Player $player
     * @param float $amount
     * @param string $reason
     * @return void
     */
    public function addMoney($player, float $amount, string $reason = "API"): void {
        $playerName = $player instanceof Player ? $player->getName() : $player;
        $this->plugin->getEconomyManager()->addBalance($playerName, $amount, $reason);
    }
    
    /**
     * Отнять деньги у игрока
     * @param string|Player $player
     * @param float $amount
     * @param string $reason
     * @return bool
     */
    public function takeMoney($player, float $amount, string $reason = "API"): bool {
        $playerName = $player instanceof Player ? $player->getName() : $player;
        return $this->plugin->getEconomyManager()->reduceBalance($playerName, $amount, $reason);
    }
    
    /**
     * Проверить, достаточно ли денег
     * @param string|Player $player
     * @param float $amount
     * @return bool
     */
    public function hasMoney($player, float $amount): bool {
        return $this->getBalance($player) >= $amount;
    }
    
    /**
     * Перевести деньги другому игроку
     * @param string|Player $from
     * @param string|Player $to
     * @param float $amount
     * @return array
     */
    public function transferMoney($from, $to, float $amount): array {
        $fromName = $from instanceof Player ? $from->getName() : $from;
        $toName = $to instanceof Player ? $to->getName() : $to;
        return $this->plugin->getEconomyManager()->transferMoney($fromName, $toName, $amount);
    }
    
    /**
     * Получить топ игроков
     * @param int $limit
     * @return array
     */
    public function getTopPlayers(int $limit = 10): array {
        return $this->plugin->getEconomyManager()->getTopPlayers($limit);
    }
    
    /**
     * Получить ранг игрока
     * @param string|Player $player
     * @return string
     */
    public function getPlayerRank($player): string {
        $playerName = $player instanceof Player ? $player->getName() : $player;
        return $this->plugin->getEconomyManager()->getPlayerRank($playerName);
    }
    
    /**
     * Получить историю транзакций игрока
     * @param string|Player $player
     * @param int $limit
     * @return array
     */
    public function getPlayerTransactions($player, int $limit = 20): array {
        $playerName = $player instanceof Player ? $player->getName() : $player;
        return $this->plugin->getEconomyManager()->getPlayerTransactions($playerName, $limit);
    }
}