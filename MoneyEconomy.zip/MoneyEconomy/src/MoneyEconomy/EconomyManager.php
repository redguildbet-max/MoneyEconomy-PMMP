<?php

namespace MoneyEconomy;

use pocketmine\player\Player;
use pocketmine\utils\Config;

class EconomyManager {

    public $plugin;
    private $data;
    private $offlineTransfers;
    private $transactions;
    private $wipeData;

    public function __construct($plugin) {
        $this->plugin = $plugin;
        $this->data = new Config($plugin->getDataFolder() . "players.json", Config::JSON);
        $this->offlineTransfers = new Config($plugin->getDataFolder() . "offline_transfers.json", Config::JSON);
        $this->transactions = new Config($plugin->getDataFolder() . "transactions.json", Config::JSON);
        $this->wipeData = new Config($plugin->getDataFolder() . "wipe_data.json", Config::JSON);
        
        // Проверяем неактивных игроков при запуске
        $this->checkInactivePlayers();
    }

    public function getPlayerData(string $playerName): array {
        $default = [
            "balance" => 10000.00,
            "spent" => 0.00,
            "earned" => 0.00,
            "limit" => -1.00,
            "rank" => "Новичок",
            "total_earned" => 0.00,
            "first_login" => time(),
            "last_login" => time()
        ];
        
        if (!$this->data->exists($playerName)) {
            $this->data->set($playerName, $default);
            $this->data->save();
        }
        
        // Убедимся, что все ключи существуют
        $currentData = $this->data->get($playerName);
        $mergedData = array_merge($default, $currentData);
        
        // Обновляем время последнего входа
        $mergedData["last_login"] = time();
        
        // Сохраняем исправленные данные
        if ($mergedData !== $currentData) {
            $this->data->set($playerName, $mergedData);
            $this->data->save();
        }
        
        return $mergedData;
    }

    public function setPlayerData(string $playerName, array $data): void {
        $data["last_login"] = time();
        $this->data->set($playerName, $data);
        $this->data->save();
        $this->updatePlayerRank($playerName);
    }

    public function addBalance(string $playerName, float $amount, string $reason = "Пополнение"): void {
        $data = $this->getPlayerData($playerName);
        $data["balance"] += $amount;
        $data["earned"] += $amount;
        $data["total_earned"] += $amount;
        $data["last_login"] = time();
        $this->setPlayerData($playerName, $data);
        $this->logTransaction($playerName, "receive", $amount, $reason);
    }

    public function reduceBalance(string $playerName, float $amount, string $reason = "Списание"): bool {
        $data = $this->getPlayerData($playerName);
        if ($data["balance"] >= $amount) {
            $data["balance"] -= $amount;
            $data["spent"] += $amount;
            $data["last_login"] = time();
            $this->setPlayerData($playerName, $data);
            $this->logTransaction($playerName, "send", $amount, $reason);
            return true;
        }
        return false;
    }

    public function getTopPlayers(int $limit = 3): array {
        $all = $this->data->getAll();
        uasort($all, function($a, $b) {
            return $b["balance"] <=> $a["balance"];
        });
        
        return array_slice($all, 0, $limit, true);
    }

    public function getTopByTotalEarned(int $limit = 10): array {
        $all = $this->data->getAll();
        uasort($all, function($a, $b) {
            return $b["total_earned"] <=> $a["total_earned"];
        });
        
        return array_slice($all, 0, $limit, true);
    }

    public function setLimit(string $playerName, float $limit): void {
        $data = $this->getPlayerData($playerName);
        $data["limit"] = $limit;
        $this->setPlayerData($playerName, $data);
    }

    public function removeLimit(string $playerName): void {
        $data = $this->getPlayerData($playerName);
        $data["limit"] = -1.00;
        $this->setPlayerData($playerName, $data);
    }

    public function hasLimit(string $playerName): bool {
        $data = $this->getPlayerData($playerName);
        return $data["limit"] !== -1.00;
    }

    public function getLimit(string $playerName): float {
        $data = $this->getPlayerData($playerName);
        return $data["limit"];
    }

    public function calculateCommission(float $amount, string $playerName): float {
        $player = $this->plugin->getServer()->getPlayerByPrefix($playerName);
        if ($player !== null && $player->hasPermission("moneyeconomy.admin")) {
            return 0;
        }
        
        $commission = $amount * 0.02;
        return max(300, min(500, $commission));
    }

    public function transferMoney(string $from, string $to, float $amount): array {
        $commission = $this->calculateCommission($amount, $from);
        $totalAmount = $amount + $commission;
        
        if ($this->reduceBalance($from, $totalAmount, "Перевод игроку " . $to)) {
            $this->addBalance($to, $amount, "Получение от " . $from);
            $this->logTransaction($from, "transfer", $totalAmount, "Перевод " . $amount . " игроку " . $to);
            $this->logTransaction($to, "receive_transfer", $amount, "Получение " . $amount . " от " . $from);
            
            return [
                "success" => true,
                "amount" => $amount,
                "commission" => $commission,
                "total" => $totalAmount
            ];
        }
        
        return [
            "success" => false,
            "error" => "Недостаточно средств"
        ];
    }

    public function addOfflineTransfer(string $to, string $from, float $amount, float $commission): void {
        $transfers = $this->offlineTransfers->get($to, []);
        $transfers[] = [
            "from" => $from,
            "amount" => $amount,
            "commission" => $commission,
            "timestamp" => time()
        ];
        $this->offlineTransfers->set($to, $transfers);
        $this->offlineTransfers->save();
    }

    public function getOfflineTransfers(string $playerName): array {
        return $this->offlineTransfers->get($playerName, []);
    }

    public function clearOfflineTransfers(string $playerName): void {
        $this->offlineTransfers->remove($playerName);
        $this->offlineTransfers->save();
    }

    public function hasOfflineTransfers(string $playerName): bool {
        $transfers = $this->getOfflineTransfers($playerName);
        return !empty($transfers);
    }

    public function logTransaction(string $player, string $type, float $amount, string $description): void {
        $transactions = $this->transactions->get($player, []);
        $transactions[] = [
            "type" => $type,
            "amount" => $amount,
            "description" => $description,
            "timestamp" => time(),
            "date" => date("d.m.Y H:i")
        ];
        $this->transactions->set($player, $transactions);
        $this->transactions->save();
    }

    public function getPlayerTransactions(string $playerName, int $limit = 20): array {
        $transactions = $this->transactions->get($playerName, []);
        usort($transactions, function($a, $b) {
            return $b["timestamp"] <=> $a["timestamp"];
        });
        return array_slice($transactions, 0, $limit);
    }

    public function getAllTransactions(int $limit = 50): array {
        $allTransactions = [];
        $players = $this->transactions->getAll();
        
        foreach ($players as $player => $transactions) {
            foreach ($transactions as $transaction) {
                $transaction["player"] = $player;
                $allTransactions[] = $transaction;
            }
        }
        
        usort($allTransactions, function($a, $b) {
            return $b["timestamp"] <=> $a["timestamp"];
        });
        
        return array_slice($allTransactions, 0, $limit);
    }

    public function startWipe(): void {
        $wipeInfo = [
            "start_time" => time(),
            "end_time" => null,
            "players_count" => count($this->data->getAll()),
            "total_money" => $this->getTotalMoneyInGame()
        ];
        
        $this->wipeData->set("current_wipe", $wipeInfo);
        $this->wipeData->save();
        
        $this->createBackup();
        
        $players = $this->data->getAll();
        foreach ($players as $playerName => $data) {
            $newData = [
                "balance" => 10000.00,
                "spent" => 0.00,
                "earned" => 0.00,
                "limit" => -1.00,
                "rank" => "Новичок",
                "total_earned" => isset($data["total_earned"]) ? $data["total_earned"] : 0.00,
                "first_login" => isset($data["first_login"]) ? $data["first_login"] : time()
            ];
            $this->data->set($playerName, $newData);
        }
        $this->data->save();
    }

    public function endWipe(): void {
        $wipeInfo = $this->wipeData->get("current_wipe", []);
        if (!empty($wipeInfo)) {
            $wipeInfo["end_time"] = time();
            $this->wipeData->set("current_wipe", $wipeInfo);
            $this->wipeData->set("last_wipe", $wipeInfo);
            $this->wipeData->remove("current_wipe");
            $this->wipeData->save();
        }
    }

    public function getCurrentWipeInfo(): array {
        return $this->wipeData->get("current_wipe", []);
    }

    public function getLastWipeInfo(): array {
        return $this->wipeData->get("last_wipe", []);
    }

    public function isInWipe(): bool {
        return !empty($this->wipeData->get("current_wipe", []));
    }

    private function getTotalMoneyInGame(): float {
        $total = 0;
        $players = $this->data->getAll();
        foreach ($players as $data) {
            $total += $data["balance"];
        }
        return $total;
    }

    private function createBackup(): void {
        $backupFile = $this->plugin->getDataFolder() . "backup_" . date("Y-m-d_H-i-s") . ".json";
        copy($this->plugin->getDataFolder() . "players.json", $backupFile);
    }

    public function updatePlayerRank(string $playerName): void {
        $data = $this->getPlayerData($playerName);
        $totalEarned = $data["total_earned"];
        $rank = $this->getRankByEarnings($totalEarned);
        
        if ($data["rank"] !== $rank) {
            $data["rank"] = $rank;
            $this->setPlayerData($playerName, $data);
            
            $player = $this->plugin->getServer()->getPlayerExact($playerName);
            if ($player !== null) {
                $player->sendMessage("Поздравляем! Ваш ранг повышен до: " . $rank);
            }
        }
    }

    private function getRankByEarnings(float $earnings): string {
        if ($earnings >= 10000000) return "Легенда";
        if ($earnings >= 5000000) return "Магнат";
        if ($earnings >= 1000000) return "Миллионер";
        if ($earnings >= 500000) return "Богач";
        if ($earnings >= 100000) return "Успешный";
        if ($earnings >= 50000) return "Опытный";
        if ($earnings >= 10000) return "Активный";
        return "Новичок";
    }

    public function getPlayerRank(string $playerName): string {
        $data = $this->getPlayerData($playerName);
        return $data["rank"] ?? "Новичок";
    }

    public function getRankPlayers(string $rank): array {
        $players = $this->data->getAll();
        $rankPlayers = [];
        
        foreach ($players as $name => $data) {
            if (isset($data["rank"]) && $data["rank"] === $rank) {
                $rankPlayers[] = [
                    "name" => $name,
                    "balance" => $data["balance"],
                    "total_earned" => $data["total_earned"]
                ];
            }
        }
        
        usort($rankPlayers, function($a, $b) {
            return $b["balance"] <=> $a["balance"];
        });
        
        return $rankPlayers;
    }

    public function getAllRanks(): array {
        return [
            "Новичок",
            "Активный",
            "Опытный",
            "Успешный",
            "Богач",
            "Миллионер",
            "Магнат",
            "Легенда"
        ];
    }

    public function resetPlayerStats(string $playerName): void {
        $data = $this->getPlayerData($playerName);
        $newData = [
            "balance" => 10000.00,
            "spent" => 0.00,
            "earned" => 0.00,
            "limit" => -1.00,
            "rank" => "Новичок",
            "total_earned" => 0.00,
            "first_login" => time(),
            "last_login" => time()
        ];
        $this->data->set($playerName, $newData);
        $this->data->save();
        
        $this->transactions->remove($playerName);
        $this->transactions->save();
    }

    // Система проверки неактивных игроков
    public function checkInactivePlayers(): void {
        $players = $this->data->getAll();
        $currentTime = time();
        $oneWeek = 7 * 24 * 60 * 60;
        $inactivePlayers = [];
        
        foreach ($players as $playerName => $data) {
            $lastLogin = isset($data["last_login"]) ? $data["last_login"] : $currentTime;
            if (($currentTime - $lastLogin) > $oneWeek) {
                $inactivePlayers[] = $playerName;
            }
        }
        
        foreach ($inactivePlayers as $playerName) {
            $this->resetInactivePlayer($playerName);
        }
        
        if (!empty($inactivePlayers)) {
            $this->plugin->getLogger()->info("Очищены данные для " . count($inactivePlayers) . " неактивных игроков");
        }
    }

    private function resetInactivePlayer(string $playerName): void {
        $this->data->remove($playerName);
        $this->offlineTransfers->remove($playerName);
        $this->transactions->remove($playerName);
        
        $this->data->save();
        $this->offlineTransfers->save();
        $this->transactions->save();
        
        $this->plugin->getLogger()->info("Данные игрока " . $playerName . " очищены (неактивен более недели)");
    }

    public function manualCheckInactivePlayers(): int {
        $players = $this->data->getAll();
        $currentTime = time();
        $oneWeek = 7 * 24 * 60 * 60;
        $count = 0;
        
        foreach ($players as $playerName => $data) {
            $lastLogin = isset($data["last_login"]) ? $data["last_login"] : $currentTime;
            if (($currentTime - $lastLogin) > $oneWeek) {
                $this->resetInactivePlayer($playerName);
                $count++;
            }
        }
        
        return $count;
    }
}